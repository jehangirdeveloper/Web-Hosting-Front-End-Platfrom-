import React from "react";
import Styles from "../Cards/Cards.module.css"
import { NavLink } from "react-bootstrap";


const Footer = () => {

  return (
    <>
    <section style={{backgroundColor:"#101522"}}>
    <div style={{backgroundColor:"#6c72a876;"}} className="section">
    <footer style={{backgroundColor:"#6c72a876;", textAlign:"left"}} id="Footer" className="page-footer font-small stylish-color-dark pt-4">
      <div style={{backgroundColor:"#6c72a876;"}} className="container text-center text-md-left">
        <div className="row">
          <div className="col-md-4 mx-auto">
            <h5 style={{textAlign:"left", color:"white"}} className=""><br />Hostings Ware Private Limited</h5>
            <hr style={{width:"65%", float:"left", color:"white"}} className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" />
            <p style={{textAlign:"left", color:"white"}}><br /><br />We as an esteemed firm that provides technological solutions in this digital 
                era with a very professional environment.</p>
          </div>
          <hr className="clearfix w-100 d-md-none" />
          <div style={{textAlign:"left", color:"white"}} id="link10" class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 style={{textAlign:"left", color:"white"}} className="text-uppercase font-weight-bold"><br />Hostings</h6>
            <hr style={{width:"60px", color:"white"}} className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" />
            <p>
              <NavLink to="#!">cPanel Hosting</NavLink>
            </p>
            <p>
              <NavLink to="#!">Shared Hosting</NavLink>
            </p>
            <p>
              <NavLink to="#!">Business Hosting</NavLink>
            </p>
          </div>
          <hr className="clearfix w-100 d-md-none" />
          <div style={{textAlign:"left", color:"white"}} id="link10" class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 className="text-uppercase font-weight-bold"><br />Services</h6>
            <hr style={{width:"60px", color:"white"}} className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" />
            <p>
              <NavLink to="#!">Mern Stack Development</NavLink>
            </p>
            <p>
              <NavLink to="#!">WordPress Development</NavLink>
            </p>
            <p>
              <NavLink to="#!">SEO Services</NavLink>
            </p>
          </div>
          <hr className="clearfix w-100 d-md-none" />
          <div style={{textAlign:"left", color:"white"}} className="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <h6 className="text-uppercase font-weight-bold"><br />Contact</h6>
            <hr style={{width:"60px", color:"white"}} className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" />
            <p>
              <i className="fas fa-home mr-3"></i>Attock City, Pakistan</p>
            <p>
              <i className="fas fa-envelope mr-3"></i>contactus@hostingsware.com</p>
            <p>
              <i className="fas fa-phone mr-3"></i> +92 3215971854</p>
            <p>
              <i className="fas fa-print mr-3"></i> Monday to Friday : 8 AM TO 6 PM</p>
          </div>
        </div>
      </div>
      <hr style={{color:"white"}} />
      <div className="hover-effect1">
      <ul style={{backgroundColor:"#6c72a876;"}} className="list-unstyled list-inline text-center">
        <li className="list-inline-item">
          <NavLink to="https://www.facebook.com/codewithfaraz" title="Facebook"><i className="fa fa-facebook"></i></NavLink>
        </li>
        <li className="list-inline-item">
          <NavLink to="https://www.twitter.com/codewithfaraz" title="Twitter"><i className="fa fa-twitter"></i></NavLink>
        </li>
        <li className="list-inline-item">
          <NavLink to="https://www.instagram.com/codewithfaraz" title="Instagram"><i className="fa fa-instagram"></i></NavLink>
        </li>
        <li className="list-inline-item">
          <NavLink to="https://www.youtube.com/@codewithfaraz" title="Youtube"><i className="fa fa-youtube"></i></NavLink>
        </li>
        <li className="list-inline-item">
          <NavLink to="#." title="Github"><i className="fa fa-github"></i></NavLink>
        </li>
      </ul>
    </div>
    <div style={{backgroundColor:"#6c72a876;", color:"white"}} className="footer-copyright text-center py-3">
    Copyright© 2021-2023: Design and Develop by Hostings Ware Private Limited
      </div>
    </footer>
    </div>
    </section>
    </>
    );
};

export default Footer;
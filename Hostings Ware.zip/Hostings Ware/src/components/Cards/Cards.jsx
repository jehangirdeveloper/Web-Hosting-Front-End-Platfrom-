import React, { useState } from "react";
import Styles from "../Cards/Cards.module.css"
import CardsApi from "../../API/CardsApi"


const CardsData = () => {
  const [CardsData, setCardsData] = useState(CardsApi);
  console.log(CardsData);
  return (
    <>
    <div className="container">
      <div className="row">
    {CardsData.map((curElem) => {
              const { backgroundImage, image, title, info } = curElem;
              return (
                <>
    <div class="col-12 col-sm-8 col-md-6 col-lg-4">
      <div style={{marginTop:"50px"}} class="card">
         <img class="card-img" src={backgroundImage} />
        <div style={{backgroundColor: "rgba(0,0,0,0.5)"}} class="card-img-overlay text-white d-flex flex-column justify-content-center">
        <img style={{height:"60px", width:"70px", marginTop:"270px", marginLeft:"130px"}} class="card-img" src={image} />
          <h4 style={{textAlign:"center", marginTop:"25px"}} class="card-title">{title}</h4>
          <p style={{textAlign:"center"}} class="card-text">{info}</p>
        </div>
      </div>
    </div>
    </>
      ); 
      })}
</div>
</div>
</>
  );
};

export default CardsData;
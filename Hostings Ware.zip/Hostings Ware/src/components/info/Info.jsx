import React, { useState } from "react";
import InfoApi from "../../API/InfoApi"


const InfoData = () => {
  const [InfoData, setInfoApi] = useState(InfoApi);
  console.log(InfoData);
  return (
    <>
      <div style={{textAlign:"center", marginTop:"-1rem"}} class="container-l p-x-0 p-x-3__l t-center">
        <div className="row">
	  <h2 style={{marginTop:"30px"}} class="t-5 t-bold p-x-2">Why USE OUR Hosting ?</h2>
	  <div class="container-l">
		<p class="sub-heading t-2 p-x-6 m-bottom-6 t-center">Because Our Customers Come First.</p>
	  </div>
      </div>
      </div>
      <div className="container">
	  <div className="row">
      {InfoData.map((curElem) => {
              const { image, title, info } = curElem;
              return (
                <>
                <div style={{maxWidth:"570px"}} class="card mb-3">
                <div className="row g-0">
                 <div className="col-md-4">
      <img style={{height:"140px", marginTop:"5px"}} src={image} class="" />
    </div>
    <div className="col-md-8">
      <div className="card-body">
		  <h3 className="Card__heading m-left-10">{title}</h3>
		  <p className="Card__content m-left-10">{info}</p>
		</div>
    </div>
    </div>
    </div>
        
    </>
      ); 
      })}
      </div>
</div>
</>
  );
};
export default InfoData;
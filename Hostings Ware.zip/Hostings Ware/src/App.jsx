import Cpanelhosting from "./Pages/cPanel Hosting/Cpanelhosting";
import Sharedhosting from "./Pages/shared hosting/Sharedhosting";
import Businesshosting from "./Pages/Business Hosting/Businesshosting";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar/Navbar";
import Signup from "./Pages/Signup/Signup";
import Login from "./Pages/Login/Login";
import Home from "./Pages/Home/Home"
import GlobalStyle from "./globalStyles";

const App = () => {
    
    return (
        
        <BrowserRouter>
        <GlobalStyle />
        <Navbar />
        <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/cpanelhosting" element={<Cpanelhosting />} />
            <Route path="/sharedhosting" element={<Sharedhosting />} />
            <Route path="/businesshosting" element={<Businesshosting />} />
            <Route path="/Signup" element={<Signup />} />
            <Route path="/Login" element={<Login />} />
            
        </Routes>
       
        </BrowserRouter>


       
    );
};

export default App;
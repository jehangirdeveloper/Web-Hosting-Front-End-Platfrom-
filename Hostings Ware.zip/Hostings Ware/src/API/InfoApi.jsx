const Info = [
    {

    image: '../images/1.jpeg',
	title: "Custom Control Panel",
	info: 'Running and managing your website should be easy. Our JCO TECH cPanel does exactly that - makes managing settings easy and fast.',
	
},

{
    title: "Support",
    info: 'US based support experts on demand. Have peace of mind knowing your website is backed with round-the-clock customer support.',
    image: '../images/2.jpeg', 
},

{
    title: "Money-Back Guarantee",
    info: 'Whether on a shared web hosting, we offer a money-back guarantee. (120-day guarantee for all hosting packages.',
    image: '../images/30.png', 
},

{
    title: "100% Uptime Guarantee",
    info: 'With multiple datacenter locations, redundant cooling, emergency generators, and constant monitoring, we are able to offer our 100% Uptime Guarantee.',
    image: '../images/100.png', 
},

{
    title: "NVME SSD",
    info: 'With NVME SSD Latest Technology, your website, caching, and database queries are faster (200% faster than HDD by our calculations).',
    image: '../images/5.png', 
},

{
    title: "Free SSL Security",
    info: 'We include Lets Encrypt SSL certificates on all domains so the data passed is always safely encrypted.',
    image: '../images/6472434.png', 
}]

export default Info
const Cards = [
    {
	title: "Hosting",
	info: 'Web Hosting Solutions for businesses of all sizes. USA Silicon Valley Hosting.',
	backgroundImage: './images/Hosting-wordpress-pic1.jpg',
    image: "./images/hosting-icon1.png"
},

{
    title: "Web Development",
    info: 'Web Development in ReactJS & Node & MongoDB & Express & also WordPress',
    backgroundImage: './images/Hosting-wordpress-pic2.jpg', 
    image: "./images/hosting-icon2.png"
},


{
    title: "SEO Services",
    info: 'We take the guesswork (and actual work) out of growing your website traffic with SEO.',
    backgroundImage: './images/Hosting-wordpress-pic3.jpg', 
    image: "./images/hosting-icon3.png"
}]

export default Cards
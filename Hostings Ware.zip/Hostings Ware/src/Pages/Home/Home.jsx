import React from "react";
import { Content } from '../../components/Content/Content';
import Cards from "../../components/Cards/Cards"
import Info from "../../components/info/Info"
import Footer from "../../components/Footer/Footer";
import { heroOne, heroTwo, heroThree, heroFour, heroFive } from './Data';


const Home = () => {
    return (
        <>
            <Content {...heroOne} />
            <Cards />
			<Content {...heroTwo} />
            <Info />
			<Content {...heroThree} />
            <Content {...heroFour} />
            <Content {...heroFive} />
            <Footer />
        </>
    );
};

export default Home;
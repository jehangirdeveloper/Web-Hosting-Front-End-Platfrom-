export const heroOne = {
	reverse: false,
	inverse: false,
	headline: "Hostings Ware",
	description: 'We are a Hostings Ware Web Hosting company. We digitalize all businesses and transform their ideas using the latest technologies.',
	buttonLabel: 'Find More',
	imgStart: 'start',
	img: './images/graceful.gif',
	start: 'false',
};

export const heroTwo = {
	reverse: true,
	inverse: true,
	headline: 'Let Us Transfer Your Website!',
	description: 'Switch to Hostings Ware and we,ll move your existing website over for free! Once you have placed your order. and we can get started right away. We migrate thousands of websites every year and we will make the entire process as seamless as possible for you. Our migration experts can transfer your website with no downtime and get you up and running at Hostings Ware in 24 hours or less.',
	imgStart: 'start',
	img: './images/Slider-3-img.svg',
	start: 'true',
};

export const heroThree = {
	reverse: false,
	inverse: true,
	headline: 'We are Here For You 24/7 With Expert Support',
	description:
		'You are in expert hands 24/7, 365 days a year, should you run into a problem. You can even choose the Advanced Support add-on for a closer support partnership or the Premium Support add-on, which gives you access to our Senior Support engineers who work as your extended in-house team!',
	imgStart: '',
	img: './images/05c6bc31c3558bce4fa8b6e6b5f527c8.png',
	start: 'true',
};

export const heroFour = {
	reverse: true,
	inverse: true,
	headline: 'Applications',
	description:
		'Build and deploy your business websites on our web hosting that supports all powered applications such as WordPress, WooCommerce, Magento, Laravel, Symfony, and Custom applications etc.',
	imgStart: '',
	img: './images/banner-img.svg',
	start: 'true',
};

export const heroFive = {
	reverse: false,
	inverse: true,
	headline: 'Latest technologies integrated',
	description:
		'We are consistently among the first hosting companies to provide their users access to the latest speed technologies. Our customers do not have to wait in order to take advantage of the newest versions or the most innovative protocols and compression algorithms like Brotli, HTTP/2, TLS 1.3 and OCSP Stapling.',
	imgStart: '',
	img: './images/slider-2-banner-img.svg',
	start: 'true',
};
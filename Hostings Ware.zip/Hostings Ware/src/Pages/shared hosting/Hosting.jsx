import React from "react";
import Styles from "../../components/Hosting/Hosting.module.css"

const HostingData = () => {

  return (
    <>
      
      <div className="container">
        <div className="row">

        <h2 style={{textAlign:"center"}}>Shared Hosting Plans</h2>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>Shared Basic</li>
    <p style={{padding: "16px 60px",}} className="grey">Ideal as you grow, with upgraded resources.</p>
    <li style={{fontSize:"30px"}}>$10.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>20 GB NVME SSD Storage</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>Shared Professional</li>
    <p style={{padding: "16px 60px",}} className="grey">Perfect for complex sites requiring more
     storage.</p>
    <li style={{fontSize:"30px"}}>$15.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>30 GB NVME SSD Storage</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>Shared Business</li>
    <p style={{padding: "16px 60px",}} className="grey">Get a full-featured online 
    with fast setup.</p>
    <li style={{fontSize:"30px"}}>$30.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>50 GB NVME SSD Storage</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

 </div>
 </div>
 <br /><br /><br />
</>
  );
};
export default HostingData;
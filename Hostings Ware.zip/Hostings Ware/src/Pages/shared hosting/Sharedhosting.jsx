import React from "react";
import { Content } from '../../components/Content/Content';
import Info from "../../components/info/Info"
import Hosting from "../shared hosting/Hosting";
import Footer from "../../components/Footer/Footer";
import { heroOne, heroTwo, heroThree, heroFour, heroFive } from './Data';


const Sharedhosting = () => {
    return (
        <>
            <Content {...heroOne} />
            <Content {...heroThree} />
            <Hosting />
            <Info />
            <Content {...heroFour} />
            <Content {...heroTwo} />
            <Content {...heroFive} />
            <Footer />
        </>
    );
};

export default Sharedhosting;
export const heroOne = {
	reverse: false,
	inverse: false,
	headline: "Shared Hosting",
	description: 'Shared Hosting is one of the most popular hosting packages because it provides an affordable way to get your website online',
	buttonLabel: 'Find More',
	imgStart: 'start',
	img: './images/pngimg.com - server_PNG56.png',
	start: 'false',
};

export const heroTwo = {
	reverse: false,
	inverse: true,
	headline: 'Build on your success.',
	description: 'Everyone has email, but that doesn’t mean all email is the same. Customers are nine times more likely to choose a business with a professional address like you@NeueBloom.com.',
	imgStart: 'start',
	img: './images/man-smile.png',
	start: 'true',
};

export const heroThree = {
	reverse: false,
	inverse: true,
	headline: 'Now, Web Hosting that,s faster — and better.',
	description:
		'With our latest optimized server hardware, you ll get faster sites — up to nearly 40% average improvement in overall server response times^. Non-Volatile Memory Express (NVMe) Solid State Drives (SSDs) Get up to a 7x throughput boost2 with our server NVMe SSDs for resource-intensive websites.',
	imgStart: '',
	img: './images/hero.png',
	start: 'true',
};

export const heroFour = {
	reverse: true,
	inverse: true,
	headline: 'What makes Hostings Ware the #1 web host?',
	description:
		'We have resources – CPU, memory, entry processes, I/O – at the ready for when you need them (we,ll alert you when you are close.) Or you can really stay on top of things through our robust stats dashboard. Either way, leveling up is a one-click affair.',
	imgStart: '',
	img: './images/welcome-ten-banne.png',
	start: 'true',
};

export const heroFive = {
	reverse: true,
	inverse: true,
	headline: 'Hosting security.',
	description:
		'Our hosting security is on the job 24/7 to monitor suspicious activity and help deflect DDoS attacks.',
	imgStart: '',
	img: './images/feature-new-2.svg',
	start: 'true',
};
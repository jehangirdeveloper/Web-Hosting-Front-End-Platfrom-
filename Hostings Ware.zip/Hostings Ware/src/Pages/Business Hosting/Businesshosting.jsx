import React from "react";
import { Content } from '../../components/Content/Content';
import Info from "../../components/info/Info"
import Hosting from "../Business Hosting/Hosting";
import Footer from "../../components/Footer/Footer";
import { heroOne, heroTwo, heroThree, heroFour, heroFive } from './Data';


const Businesshosting = () => {
    return (
        <>
            <Content {...heroOne} />
            <Content {...heroThree} />
            <Content {...heroTwo} />
            <Hosting />
            <Info />
            <Content {...heroFour} />
            <Content {...heroFive} />
            <Footer />
        </>
    );
};

export default Businesshosting;
export const heroOne = {
	reverse: true,
	inverse: false,
	headline: "Buisness Hosting",
	description: 'Get online with Hostings Ware ideal for developers and those who run ecommerce or high traffic websites.',
	buttonLabel: 'Find More',
	imgStart: 'start',
	img: './images/banner-3.gif',
	start: 'false',
};

export const heroTwo = {
	reverse: true,
	inverse: true,
	headline: 'Build on your success.',
	description: 'Everyone has email, but that doesn’t mean all email is the same. Customers are nine times more likely to choose a business with a professional address like you@NeueBloom.com.',
	imgStart: 'start',
	img: './images/feature-img.png',
	start: 'true',
};

export const heroThree = {
	reverse: false,
	inverse: true,
	headline: 'Which hosting solution is best for your needs?',
	description:
		'Business Hosting Plus dedicate specific portions of a web server’s capacity and processing to each customer. Like a condo, your space (on the server) is yours.',
	imgStart: '',
	img: './images/laptop-server.png',
	start: 'true',
};

export const heroFour = {
	reverse: true,
	inverse: true,
	headline: 'The vision for our mission',
	description:
		'We’ve helped people make their own way online. You can trust us to do the same for you.',
	imgStart: '',
	img: './images/banner-one-img-1.png',
	start: 'true',
};

export const heroFive = {
	reverse: false,
	inverse: true,
	headline: 'Hosting security.',
	description:
		'Our hosting security is on the job 24/7 to monitor suspicious activity and help deflect DDoS attacks.',
	imgStart: '',
	img: './images/desk.png',
	start: 'true',
};
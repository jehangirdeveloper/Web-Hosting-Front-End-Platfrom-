import React from "react";
import Styles from "../../components/Hosting/Hosting.module.css"

const HostingData = () => {

  return (
    <>
      
      <div className="container">
        <div className="row">

        <h2 style={{textAlign:"center"}}>Business Hosting Plans</h2>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>Business Golden </li>
    <p style={{padding: "16px 60px",}} className="grey">Our most economical hosting — works with Professional websites. Select plan include free domain and email.</p>
    <li style={{fontSize:"30px"}}>$50.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>100 GB NVME SSD Storage</li>
    <li>1 Year Free .com, .net, .org Domain</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>


<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>Business Delux </li>
    <p style={{padding: "16px 60px",}} className="grey">Business hosting with VPS-like power, 
     Great for growing sites, 
    ecommerce, CMS and high traffic.</p>
    <li style={{fontSize:"30px"}}>$60.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>150 GB NVME SSD Storage</li>
    <li>1 Year Free .com, .net, .org Domain</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>


<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>Business Plus </li>
    <p style={{padding: "16px 60px",}} className="grey">Highly customizable for resource-intensive 
    web applications. Easy use control panel options, NVME SSD or on bare metal servers.</p>
    <li style={{fontSize:"30px"}}>$100.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>200 GB NVME SSD Storage</li>
    <li>1 Year Free .com, .net, .org Domain</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

 </div>
 </div>
 <br /><br /><br />
</>
  );
};
export default HostingData;
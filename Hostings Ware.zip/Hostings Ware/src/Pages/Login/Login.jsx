import React from "react";
import styles from "../Login/Login.module.css"
import Footer from "../../components/Footer/Footer";
import { NavLink } from "react-bootstrap";

const Login = () => {

  return (
 <>
        <section style={{backgroundColor:"hwb(238 31% 25%)"}} className="login">
    <div style={{backgroundColor:"blue"}} className={styles.container}>
      <div className={`${styles.user} ${styles.signinBx}`}>
        <div className={styles.imgBx}><img src="./images/man-speed.png" alt="" /></div>
        <div className={styles.formBx}>
        <form action="" onsubmit="return false;">
            <h2>SIGN IN</h2>
            <input type="text" name="" placeholder="Username" />
            <input type="password" name="" placeholder="Password" />
            <input type="submit" name="" value="Sign In" />
            <p className={styles.signup}>
            DON'T HAVE AN ACCOUNT ?
              <NavLink href="Signup">Sign UP</NavLink>
            </p>
          </form>
        </div>
      </div>
     </div>
  </section>

  <Footer />
</>
  )
}

export default Login
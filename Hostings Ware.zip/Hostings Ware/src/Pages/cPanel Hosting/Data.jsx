export const heroOne = {
	reverse: true,
	inverse: false,
	headline: "cPanel Hosting",
	description: 'Makes cPanel faster, more secure, & hassle-free. One-click installs so you can build happy.',
	buttonLabel: 'Find More',
	imgStart: 'start',
	img: './images/cpanel-web-hosting.png',
	start: 'false',
};

export const heroTwo = {
	reverse: false,
	inverse: true,
	headline: 'Build on your success.',
	description: 'Everyone has email, but that doesn’t mean all email is the same. Customers are nine times more likely to choose a business with a professional address like you@NeueBloom.com.',
	imgStart: 'start',
	img: './images/business-email-email-removebg-preview.png',
	start: 'true',
};

export const heroThree = {
	reverse: false,
	inverse: true,
	headline: 'Protect your data and your customers.',
	description:
		'An SSL Certificate protects the data going to and from your site — from personal info to credit card numbers. And when visitors feel safe, they are more likely to give you their business.',
	imgStart: '',
	img: './images/depositphotos.jpeg',
	start: 'true',
};

export const heroFour = {
	reverse: true,
	inverse: true,
	headline: 'Fast, secure and always online.',
	description:
		'Already have a website? Give it the home it deserves. With industry-leading load times, guaranteed 99.9% uptime and expert, 24/7 support, your site couldn’t ask for more.',
	imgStart: '',
	img: './images/uds.png',
	start: 'true',
};

export const heroFive = {
	reverse: true,
	inverse: true,
	headline: 'Why go with Hostings Ware?',
	description:
		'Because we know that even the best technology is only as good as the people behind it. That’s why we offer expert support, plus a lot more.',
	imgStart: '',
	img: './images/hero-bg.png',
	start: 'true',
};
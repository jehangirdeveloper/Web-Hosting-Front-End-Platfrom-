import React from "react";
import Styles from "../../components/Hosting/Hosting.module.css"

const HostingData = () => {

  return (
    <>
      
      <div className="container">
        <div className="row">

        <h2 style={{textAlign:"center"}}>cPanel Hosting Plans</h2>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>cPanel Basic</li>
    <p style={{padding: "16px 60px",}} className="grey">Multiple site hosting with SSL for all sites.
     and free email (with terms of 12/mo. or longer).</p>
    <li style={{fontSize:"30px"}}>$3.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>5 GB NVME SSD Storage</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>cPanel Professional</li>
    <p style={{padding: "16px 60px",}} className="grey">Increased processing power with 
    multiple sites, and free email (with terms of 12/mo. or longer).</p>
    <li style={{fontSize:"30px"}}>$5.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>10 GB NVME SSD Storage</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

<div className={Styles.columns}>
  <ul className={Styles.price}>
    <li className={Styles.header}>cPanel Ultimate</li>
    <p style={{padding: "16px 60px",}} className="grey">Maximized processing power and speed, 
    SSL for all sites. and free email (with terms of 12/mo.)</p>
    <li style={{fontSize:"30px"}}>$8.99/yearly</li>
    <button style={{
  border: "none",
  color: "black",
  padding: "16px 80px",
  textDecoration: "none",
  display: "inline-block",
  fontSize: "16px",
  margin: "4px 45px",
  cursor: "pointer"}} class="button button5">Buy Now</button>
    <li>15 GB NVME SSD Storage</li>
    <li>Unlimited Addons Domains</li>
    <li>Unlimited Sub Domains</li>
    <li>Unlimited Bandwidth</li>
    <li>Unlimited Database</li>
    <li>Unlimited FTP Accounts</li>
    <li>Fast SSD Storage</li>
    <li>Free SSL Certificate</li>
    <li>Unlimited Emails</li>
    <li>120-Day Money-Back Guarantee</li>
    <li>USA Silicon Valley Data Center</li>
  </ul>
</div>

 </div>
 </div>
 <br /><br /><br />
</>
  );
};
export default HostingData;
import React from "react";
import styles from "../Signup/Signup.module.css"
import Footer from "../../components/Footer/Footer";
import { NavLink } from "react-bootstrap";

const Signup = () => {

  return (
 <>
        <section style={{backgroundColor:"hwb(238 31% 25%)"}} className="signup">
    <div className={styles.container}>
      <div className={`${styles.user} ${styles.signinBx}`}>
        <div className={styles.imgBx}><img src="./images/sign-up.png" alt="" /></div>
        <div className={styles.formBx}>
        <form action="" onsubmit="return false;">
            <h2>Create an account</h2>
            <input type="text" name="" placeholder="Username" />
            <input type="email" name="" placeholder="Email Address" />
            <input type="password" name="" placeholder="Create Password" />
            <input type="password" name="" placeholder="Confirm Password" />
            <input type="submit" name="" value="Sign Up" />
            <p className={styles.signup}>
              Already have an account ?
              <NavLink href="Login">Login</NavLink>
            </p>
          </form>
        </div>
      </div>
     </div>
  </section>

  <Footer />
</>
  )
}

export default Signup
import {
  DefaultContext,
  GenIcon,
  IconBase,
  IconContext,
  IconsManifest
} from "./chunk-MQ356XNR.js";
import "./chunk-2FATVHAI.js";
export {
  DefaultContext,
  GenIcon,
  IconBase,
  IconContext,
  IconsManifest
};
//# sourceMappingURL=react-icons_lib.js.map
